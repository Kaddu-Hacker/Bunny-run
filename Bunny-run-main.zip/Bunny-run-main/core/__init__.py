# Package initialization for core module
